rootProject.name = "com.example.doodling-doods-server"
