rootProject.name = "com.doodling-doods-server"
