create function interval_pl_date(interval, date) returns timestamp without time zone
    immutable
    strict
    parallel safe
    cost 1
    language sql
RETURN ($2 + $1);

comment on function interval_pl_date(interval, date) is 'implementation of + operator';

alter function interval_pl_date(interval, date) owner to postgres;

